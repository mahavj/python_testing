"""The function is defined here"""
import sys
import logging
def  trig_cosh(number):
    """The function to calculate cosh"""
    logging.basicConfig(filename="confile.log",level=logging.ERROR,format='%(asctime)s:%(levelname)s:%(message)s',filemode='w')
    try:
        if "." in str(number):
            number = float(number)
        else:
            number = int(number)
        calculate = 2.71828**number / 2 + 2.71828**-number / 2
        return calculate
    except ValueError as e:
        logging.error(e.message)
        return "Value error"

