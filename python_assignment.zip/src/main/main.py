from src.calculator import cosh_logic_program
import sys


def main():
    value = (sys.argv[1])
    result = cosh_logic_program.trig_cosh(value)
    print(result)